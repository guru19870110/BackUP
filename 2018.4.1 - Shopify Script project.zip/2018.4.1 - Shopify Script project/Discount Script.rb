customer = Input.cart.customer
 # Current price variable : current_price
current_price = Money.zero
# Start of Check the customer history
if customer.orders_count == 0
	Input.cart.line_items.each do |item|
		current_price = item.line_price + current_price
	end
end
# End of check the customer history
# Start of the check the current cart price amount with each products.
# if current_price < Money.new(cents: 300000)
#   Input.cart.line_items.each do |item|
#     item.change_line_price(item.line_price * 0.5, message: "50% discount")
#   end
# end
# End of the check the current cart price amount with each products.
# Start of the stop the discount code for the 3000$ 
if current_price > Money.new(cents: 300000)
  	Input.cart.discount_code.reject(message: "Over 3000")
end
# End of the stop the discount code for the 3000$
Output.cart = Input.cart