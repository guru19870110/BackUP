------------------------------ Try Everything ---------------------------------


I messed up tonight
I lost another fight
I still mess up but I'll just start again
I keep falling down
I keep on hitting the ground
I always get up now to see what's next
Birds don't just fly
They fall down and get up
Nobody learns without getting it won
I won't give up, no I won't give in
Till I reach the end
And then I'll start again
Though I'm on the lead
I wanna try everything
I wanna try even though I could fail
I won't give up, no I won't give in
Till I reach the end
And then I'll start again
No I won't leave
I wanna try everything
I wanna try even though I could fail
Oh oh try everything
Look how far you've come
You filled your heart with love
Baby you've done enough that cut your breath
Don't beat yourself up
Don't need to run so fast
Sometimes we come last but we did our best
I won't give up, no I won't give in
Till I reach the end
And then I'll start again
Though I'm on the lead
I wanna try everything
I wanna try even though I could fail
I won't give up, no I won't give in
Till I reach the end
And then I'll start again
No I won't leave
I wanna try everything
I wanna try even though I could fail
I'll keep on making those new mistakes
I'll keep on making them every day
Those new mistakes
Oh oh, try everything


--------------------------------------------- We are the World! -----------------------------------------
There is a time when we should hear the certain calls
'Cause the world it seems it's right in this line
'Cause there's a chance for taking in needing our own lives
It seems we need nothing at all
I used to feel I should give away my heart
And it shows that fear of needing them
Then I read the headlines and it said they're dying there
And it shows that we must heed instead
We are the world
We are the children
We are the ones who make a brighter day
So let's start giving
There's a chance we're taking
We're taking our own lives
It's true we'll make a brighter day
Just you and me
Give in your heart and you will see that someone cares
'Cause you know that they can feed them all
Then I read the paper and it said that you've been denied
And it shows the second we will call
We are the world
We are the children
We are the ones who make a brighter day
So let's start giving
There's a chance we're taking
We're taking our own lives
It's true we'll make a brighter day
Just you and me
Now there's a time when we must love them all
And it seems that life, it don't make love at all
But if you'd been there, and I'll love you more and more
It seems in life, I didn't do that
We are the world, the world
We are the children, are the children
We are the ones who make a brighter day
So let's start giving, let's start giving
There's a chance we're taking
We're taking our own lives
It's true we'll make a brighter day
Just you and me
We are the world, are the world
We are the children, are the children
We are the ones who make a brighter day
So let's start giving, let's start giving
But there's a chance we're taking, taking
We're taking our own lives
It's true we'll make a brighter day
Just you and me
We are the world, shalom
We are the children, shalingin
We are the ones who make a brighter day, shalom
So let's start giving, 'cause that's what we're being
There's a chance we're taking
We're taking our own lives
It's true we'll make a brighter day
Just you and me
Come on, yeah
We are the world, shalom
We are the children, shalingin
We are the ones who make a brighter day, shalom
So let's start giving, 'cause that's what we're being
There's a chance we're taking
We're taking our own lives
It's true we'll make a brighter day
Just you and me
Oh yeah, we got it
We are the world, shalom
We are the children, shalingin
We are the ones who make a brighter day, shalom
So let's start giving, cause that's what we're being
There's a chance we're taking
We're taking our own lives
It's true we'll make a brighter day