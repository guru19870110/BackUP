--------------------------------------- My Account Information---------------------------------------


-GitHub account
Username: SkeletonKing
Email: slark0704@gmail.com
Password: qwerqwer1234

-Gmail
Eamil: slark0704@gmail.com
Password: qwerslark199274

-Outlook Mail
Email: victor19920407@outlook.com
Password: Tarzan199247

-Slack Account
Name: UP
Password: Morjelat1234

-Ase Naritoshi Account Skype
Email: lapin.peter@outlook.com
Password: darkhorsecktjfrud!!24

-Ase Naritoshi Account Slack
Name: Ase Naritoshi
Display Name: Ase N.
Password: Morjelat1234

-Apple ID
Name: Vladimir Kupchenko
Email: slark0704@gmail.com
Password: Morjelat147
Favorite team: Real Madrid
Model Car: Benz
First Pet: Tiger

-QQ Account
ID: 3139604072
Password: qwer1234


------------------------------------- Project Account Information ----------------------------------------

-PigBi project
	Username:
	Password:

-Ruby on Rails Project.
Server Information
Details: 158.69.210.30
Username: root
Password: KJaYMTI5

-Discourse
Email: slark0704@gmail.com
Username: Slark
Name: Yunero
Password: Morjelat1234

-Node.js Project
IP Address: 206.189.196.175
Username: root
Password: 2526e4d94e0109402b0e6d885f




--------------------------------------- Mr Hae Account Information ------------------------------------------









--------------------------------------- Mr Ase Account Information ------------------------------------------
1. Freelancer gmail:
	Gmail:		asenaritoshi@gmail.com
	Pwsd:		darkhorsecktjfrud!!24
	Account:	Ase!!@$Naritoshi1124account
	Facebook:	star123!@#

2. Upwork hotmail:
	Hotmail:	cck1124@hotmail.com
	Pwsd:		darkhorsecktjfrud!!24
	Account:	darkhorsecktjfrud!!24
	Skype Possible.
	Questions:	myway

3. Gmails Registered to Paypal.
	Gmail:		asenaritoshi@gmail.com
	Pwsd: 		above

	Gmail:		maximb1124@gmail.com
	Pwsd: 		darkhorsecktjfrud!!@$

4. Others:
	Outlook:	lapin.peter@outlook.com
	Pwsd:		darkhorsecktjfrud!!24
	Skype Possible.

	Gmail:		lapin.peter87@gmail.com
	Pwsd: 		darkhorsecktjfrud

5. Guru:
	Gmail:		maximb1124@gmail.com
	Pwsd:		Darkhorsecktjfrud!!@$1992
	Questions: 	City: London, Color: White
	
6. VM:
	Mac:		darkhorserladudtla
	Ubuntu:		darkhorsecktjfrud
	Win7:		darkhorsecktjfrud

7. Git
	Username: 	maximborislav
	Gmail:		maximb1124@gmail.com
	Pwsd:		Darkhorsecktjfrud!!24